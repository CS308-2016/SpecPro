Project Name:
SpecPro

Team Members:
1. Prateesh Goyal	120050013
2. Pratyaksh Sharma	120050019
3. Ramprakash K		120050083
4. Viplov Jain		120050084

Project Description:
Speed and congestion detection using proximity sensors.

Videos:
=======
Screencast: https://www.youtube.com/watch?v=-hxPXcVsC_s
Demo: https://www.youtube.com/watch?v=uXh3ykEPQQw


